# @v5md/vue

`@v5md/view` 的 Vue 3 封装。组件名是 `V5Editor`，用 `v-model` 绑定 Markdown 字符串。

peer dependency 是 `vue@^3.4.0`。样式仍从 `@v5md/view/theme.css` 引入，本包不打包主题。

## 用法

```vue
<script setup lang="ts">
import { ref, shallowRef } from 'vue'
import type { Editor } from '@v5md/view'
import { V5Editor } from '@v5md/vue'
import '@v5md/view/theme.css'

const markdown = ref('# 标题\n')
const editor = shallowRef<Editor | null>(null)

function onUploadImage(file: File) {
  return URL.createObjectURL(file)
}
</script>

<template>
  <V5Editor
    v-model="markdown"
    placeholder="开始编写…"
    :on-upload-image="onUploadImage"
    :on-ready="(instance) => (editor = instance)"
  />
</template>
```

## 属性

| 属性 | 说明 |
| --- | --- |
| `v-model` / `modelValue` | Markdown 全文。外部改成与编辑器不同的字符串时，会调用 `setMarkdown` |
| `placeholder` | 空文档提示，变化时同步到编辑器 |
| `editable` | 是否可编辑，默认 `true`。传 `false` 进入只读预览，变化时调用 `setEditable`；预览下待办复选框仍可切换 |
| `plugins` | 插件数组，挂载时传给 `Editor` |
| `onUploadImage` | `(file: File) => string \| Promise<string>` |
| `onPickImage` | 点击工具条图片按钮时调用；返回 `false` 则继续使用系统文件选择框 |
| `onFindRequest` | `(request: { kind: 'find' \| 'replace' }) => void`。不传时按 Mod+F / Mod+H 打开内置查找栏 |
| `onReady` | 挂载完成后拿到 `Editor` 实例 |

编辑器只在挂载时创建一次。`modelValue`、`editable`、`placeholder` 以及各回调的后续变化都不会重建编辑器，而是直接同步到实例。

`plugins` 只在挂载时读取。运行时安装插件可以通过 `onReady` 拿到实例后调用 `editor.use(plugin)`，卸载调用返回句柄的 `dispose()`。

`onReady` 里的实例可以调用 `undo`、`redo`、`openFind`、`setSourceMode`、`setToolbarVisible`、`setOutlineVisible`、`copyForWechat`、`use`、`runCommand` 等视图层方法。工具条最右侧的「复制到公众号」会生成带内联样式的富文本，也可以直接调用 `editor.copyForWechat()`。工具条和大纲默认显示。

组件销毁时会 `destroy()` 编辑器。根元素带 `v5md-host`，传入的 class 和属性会落到这个元素上。

## 构建

```bash
npm run build -w @v5md/vue
```
